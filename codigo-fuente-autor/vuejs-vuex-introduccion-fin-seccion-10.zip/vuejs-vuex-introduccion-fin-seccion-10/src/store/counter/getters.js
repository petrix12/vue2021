

export const squareCount = ( state ) => {
    return state.count * state.count
}

